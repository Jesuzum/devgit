from ui import ui_init

if __name__ == "__main__":
    ui_init()