from a_lexico import AnalizadorLexico

def main():
    # Crear el objeto AnalizadorLexico
    analizador_lexico = AnalizadorLexico()

    # Analizar el archivo 'codigo_perl.txt'
    analizador_lexico.analizar("codigo_perl.txt")

    # Mostrar los tokens generados
    analizador_lexico.mostrar_tokens()

    # Mostrar los errores (si hay)
    analizador_lexico.mostrar_errores()

if __name__ == "__main__":
    main()
